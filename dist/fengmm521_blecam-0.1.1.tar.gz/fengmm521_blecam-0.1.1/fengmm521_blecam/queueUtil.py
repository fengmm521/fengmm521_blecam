
class imgDataObj():
    def __init__(self,pdat):
        self.dat = pdat.copy()